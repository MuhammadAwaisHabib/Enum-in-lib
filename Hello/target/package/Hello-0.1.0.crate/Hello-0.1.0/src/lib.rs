pub fn helo(a: i32,z: i32) {
    for index in a..z{
        println!("{}",index)
    }
}