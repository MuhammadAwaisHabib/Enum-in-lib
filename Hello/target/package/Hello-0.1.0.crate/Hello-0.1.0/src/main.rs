use Hello::helo;
fn main() {
    println!("Hello, world!");
    helo(1,51);
}